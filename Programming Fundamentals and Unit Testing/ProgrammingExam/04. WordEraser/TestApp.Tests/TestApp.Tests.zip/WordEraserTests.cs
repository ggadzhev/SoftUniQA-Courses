﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace TestApp.Tests;

public class WordEraserTests
{
    [Test]
    public void Test_Erase_EmptyWordsList_ShouldReturnEmptyString()
    {
        List<string> emptyList = new List<string>();
        string eraserWord = string.Empty;
        string expectedResult = string.Empty;

        WordEraser eraser = new WordEraser();
        // Act
        string actualResult = eraser.Erase(emptyList, eraserWord);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);

    }

    [Test]
    public void Test_Erase_NullWordsList_ShouldReturnEmptyString()
    {
        List<string> emptyList = null;
        string eraserWord = null;
        string expected = string.Empty;

        WordEraser eraser = new WordEraser();
        //Act
        string actual = eraser.Erase(emptyList, eraserWord);
        //Asert
        Assert.AreEqual(expected, actual);
    }

    [Test]
    public void Test_Erase_NullOrEmptyWordToErase_ShouldReturnStringOfGivenWordsList()
    {
        List<string> emptyList = new List<string>() { "test","test","one", null };
        string eraserWord = null;
        string expectedResult = "test test one ";

        WordEraser eraser = new WordEraser();
        // Act
        string actualResult = eraser.Erase(emptyList, eraserWord);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);
    }

    [Test]
    public void Test_Erase_ValidInput_ShouldReturnEmptyString_WhenAllWordsMatchedTheWordToErase()
    {
        List<string> emptyList = new List<string>() { "test", "test", "test" };
        string eraserWord = "test";
        string expectedResult = string.Empty;

        WordEraser eraser = new WordEraser();
        // Act
        string actualResult = eraser.Erase(emptyList, eraserWord);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);
    }

    [Test]
    public void Test_Erase_ValidInput_ShouldReturnStringWithoutErasedWords_WhenFewOfWordsMatchedWordToArese()
    {
        List<string> emptyList = new List<string>() { "two", "One", "two", "two", "One" };
        string eraserWord = "one"; ;
        string expectedResult = "two One two two One";

        WordEraser eraser = new WordEraser();
        // Act
        string actualResult = eraser.Erase(emptyList, eraserWord);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);
    }
}

